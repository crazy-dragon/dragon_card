/* ==========================================================================
   汉语量词 195 · 小工具
   --------------------------------------------------------------------------
   1 张 intro 卡 + 195 个量词，按七类分组（数据里的 category）：

     个体 75 · 集合 31 · 度量 28 · 容器 23 · 动作 17 · 时间 14 · 类别 7

   两种视图（顶栏分段切换）：
     chart 分类速查   七类分段，段内网格排开（量词 + 拼音 + HSK 等级），
                      点格子 = 读量词 + 跳到那张卡。查「「条」怎么用」时
                      这就是一张真速查表。
     card  卡片       量词 / 拼音 / HSK 等级 / 英文用法 / 搭配 chips（可点读）
                      / 中英例句（可点读）。

   朗读通道（浏览器 TTS，zh-CN）：
     🔊        -> 读量词（audio_play）
     点搭配chip -> 读整个搭配，如「一条河」（word_play）
     点例句    -> 读整句（word_play）

   「只看 HSK1-4」筛选（seedling 按钮）：level 1-4 的 89 个是初学者核心，
   数据口径 = HSK 1-4 级（Extra 是词表外补充）。

   宿主桥接 window.cardAPI（/v1/tools/<id>/run 注入）：
     deckId / userId / getPage / mark / favorite / track / finish
   ========================================================================== */
(function () {
  'use strict';

  var TOOL = window.DC_TOOL || {};
  var TITLE = TOOL.title || '汉语量词';
  var VOICE_LANG = TOOL.voiceLang || 'zh-CN';
  var VIEWS = (TOOL.views && TOOL.views.length) ? TOOL.views : [
    { id: 'chart', label: '分类速查' },
    { id: 'card',  label: '卡片' }
  ];
  var PAGE_SIZE = 500;
  var LS = 'dc-mw-';

  var SKINS = [
    { id: 'cream', name: '奶油', icon: 'fa-sun' },
    { id: 'glass', name: '墨玻璃', icon: 'fa-moon' },
    { id: 'category', name: '分类彩', icon: 'fa-gem' }
  ];

  /* 七类（数据里的 category 原文）—— 色值从原模板 CAT_MAP 原样搬来 */
  var CATS = ['个体', '集合', '容器', '度量', '时间', '动作', '类别'];
  var CAT_EN = { '个体': 'individual objects', '集合': 'pairs, sets & groups', '容器': 'containerfuls',
                 '度量': 'units & measures', '时间': 'time spans', '动作': 'counting actions', '类别': 'kinds & types' };
  function catClass(c) { return 'mc-' + CATS.indexOf(c); }
  function catOf(c) { return CATS.indexOf(c) >= 0 ? CATS.indexOf(c) : 6; }

  var LV_TEXT = { '1': 'HSK1', '2': 'HSK2', '3': 'HSK3', '4': 'HSK4', '5': 'HSK5', '6': 'HSK6', '7-9': 'HSK7-9', 'Extra': 'HSK+' };
  function coreLevel(lv) { return ['1', '2', '3', '4'].indexOf(String(lv)) >= 0; }

  var state = {
    deckId: (window.cardAPI || {}).deckId,
    userId: (window.cardAPI || {}).userId,
    all: [],
    intro: null,
    view: 'chart',
    singleCardMode: false,
    singleCardIndex: 0,
    skin: 'cream',
    fontSize: 1,
    coreOnly: false,
    _voiceWarned: false,
    _refreshLock: false
  };
  try {
    var sv = localStorage.getItem(LS + 'view');
    if (sv && VIEWS.some(function (v) { return v.id === sv; })) state.view = sv;
  } catch (e) {}
  try { var ss = localStorage.getItem(LS + 'skin'); if (ss) state.skin = ss; } catch (e) {}
  if (!SKINS.some(function (s) { return s.id === state.skin; })) state.skin = 'cream';
  try { state.fontSize = parseFloat(localStorage.getItem(LS + 'font')) || 1; } catch (e) {}
  try { state.coreOnly = localStorage.getItem(LS + 'core') === '1'; } catch (e) {}

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $id(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  /* ===== toast / tooltip ===== */
  var _toastTimer = null;
  function showToast(msg, isError) {
    var el = $id('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast show' + (isError ? ' error' : '');
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(function () { el.className = 'toast' + (isError ? ' error' : ''); }, 2500);
  }
  function initTooltip() {
    var timer = null, current = null;
    function hide() {
      clearTimeout(timer); timer = null; current = null;
      var tip = $id('global-tooltip');
      if (tip) tip.classList.remove('show');
    }
    document.addEventListener('mouseover', function (e) {
      var t = e.target;
      if (!t || typeof t.closest !== 'function') return;
      var el = t.closest('[data-tooltip]');
      if (!el || el === current) return;
      current = el;
      clearTimeout(timer);
      timer = setTimeout(function () {
        var text = el.getAttribute('data-tooltip');
        if (!text) return;
        var tip = $id('global-tooltip');
        if (!tip) return;
        tip.textContent = text;
        tip.classList.add('show');
        var r = el.getBoundingClientRect();
        var tr = tip.getBoundingClientRect();
        var left = r.left + r.width / 2 - tr.width / 2;
        var top = r.bottom + 8;
        if (left < 8) left = 8;
        if (left + tr.width > window.innerWidth - 8) left = window.innerWidth - tr.width - 8;
        if (top + tr.height > window.innerHeight - 8) top = r.top - tr.height - 8;
        tip.style.left = left + 'px';
        tip.style.top = top + 'px';
      }, 300);
    });
    document.addEventListener('mouseleave', function (e) {
      var t = e.target;
      if (!t || typeof t.closest !== 'function') { hide(); return; }
      if (t.closest('[data-tooltip]')) hide();
    });
    document.addEventListener('mousedown', hide);
    window.addEventListener('scroll', hide, true);
  }

  /* ===== 音色 ===== */
  var voiceMgr = {
    voices: [],
    init: function () {
      var self = this;
      function load() {
        self.voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
        renderVoiceDropdown();
      }
      if (window.speechSynthesis) {
        load();
        if (window.speechSynthesis.onvoiceschanged !== undefined) window.speechSynthesis.onvoiceschanged = load;
      }
    },
    _primary: function (tag) { return String(tag || '').split('-')[0].toLowerCase(); },
    pickVoice: function (lang) {
      if (!lang) return null;
      var primary = this._primary(lang);
      var saved = null;
      try { saved = localStorage.getItem('dc-voice-' + primary); } catch (e) {}
      var fallback = null;
      for (var i = 0; i < this.voices.length; i++) {
        var v = this.voices[i];
        if (saved && v.voiceURI === saved) return v;
        if (!fallback && this._primary(v.lang) === primary) fallback = v;
        if (v.lang && v.lang.toLowerCase() === String(lang).toLowerCase()) return v;
      }
      return fallback;
    },
    saveVoice: function (lang, voice) {
      try { localStorage.setItem('dc-voice-' + this._primary(lang), voice ? voice.voiceURI : ''); } catch (e) {}
    },
    sampleText: function () { return '一条河，一杯茶'; },
    speak: function (text, lang) {
      if (!('speechSynthesis' in window)) { showToast('这个浏览器不支持朗读', true); return; }
      var u = new SpeechSynthesisUtterance(text || '');
      var voice = this.pickVoice(lang || VOICE_LANG);
      if (voice) u.voice = voice;
      else if (lang) u.lang = lang;
      try {
        window.speechSynthesis.cancel();
        if (window.speechSynthesis.paused) window.speechSynthesis.resume();
        setTimeout(function () { window.speechSynthesis.speak(u); }, 80);
      } catch (e) {}
    }
  };
  function warnIfNoVoice() {
    if (state._voiceWarned) return;
    if (voiceMgr.pickVoice(VOICE_LANG)) return;
    state._voiceWarned = true;
    showToast('系统里没有中文语音包，读音可能不准', false);
  }
  function renderVoiceDropdown() {
    var list = $('.voice-list');
    if (!list) return;
    list.innerHTML = '';
    var lang = voiceMgr._primary(VOICE_LANG);
    var voices = voiceMgr.voices.filter(function (v) { return voiceMgr._primary(v.lang) === lang; });
    var pick = voiceMgr.pickVoice(VOICE_LANG);
    var activeUri = pick ? pick.voiceURI : null;
    if (!voices.length) {
      var empty = document.createElement('div');
      empty.className = 'voice-option muted';
      empty.textContent = '系统里没有中文语音包，点一下用默认的试听。';
      empty.addEventListener('click', function () {
        voiceMgr.saveVoice(VOICE_LANG, null);
        voiceMgr.speak(voiceMgr.sampleText(), VOICE_LANG);
        renderVoiceDropdown();
      });
      list.appendChild(empty);
      return;
    }
    voices.forEach(function (v) {
      var opt = document.createElement('div');
      opt.className = 'voice-option' + (v.voiceURI === activeUri ? ' active' : '');
      opt.dataset.voiceUri = v.voiceURI;
      opt.textContent = v.name;
      list.appendChild(opt);
    });
  }

  /* ===== 皮肤 / 字号 ===== */
  function applySkin() {
    var h = document.documentElement;
    SKINS.forEach(function (s) { h.classList.remove('skin-' + s.id); });
    h.classList.add('skin-' + state.skin);
    try { localStorage.setItem(LS + 'skin', state.skin); } catch (e) {}
    renderSkinList();
  }
  function renderSkinList() {
    var list = $id('style-list');
    if (!list) return;
    list.innerHTML = SKINS.map(function (s) {
      return '<div class="skin-option' + (state.skin === s.id ? ' active' : '') + '" data-style="' + s.id + '">' +
        '<i class="fa-solid ' + s.icon + '"></i><span>' + esc(s.name) + '</span></div>';
    }).join('');
  }
  function applyCardFont() {
    document.documentElement.style.setProperty('--card-font-scale', String(state.fontSize));
    var v = $id('font-size-value');
    if (v) v.textContent = Math.round(state.fontSize * 100) + '%';
    try { localStorage.setItem(LS + 'font', state.fontSize); } catch (e) {}
  }

  /* ===== 数据 ===== */
  function loadAll() {
    if (!window.cardAPI || !cardAPI.getPage) return Promise.resolve();
    return cardAPI.getPage(1, PAGE_SIZE).then(function (d) {
      var cards = (d.cards || []).slice();
      state.intro = null;
      state.all = [];
      cards.forEach(function (c) {
        if ((c.data || {}).type === 'intro') { if (!state.intro) state.intro = c; }
        else state.all.push(c);
      });
    });
  }
  function findCard(id) {
    for (var i = 0; i < state.all.length; i++) if (String(state.all[i].id) === String(id)) return state.all[i];
    return null;
  }
  function visibleCards() {
    if (!state.coreOnly) return state.all;
    return state.all.filter(function (c) { return coreLevel((c.data || {}).level); });
  }
  function updateStatsText() {
    var marked = state.all.filter(function (c) { return c.is_unknown === 1; }).length;
    var el = $('#refresh-stats span');
    if (el) el.textContent = marked + ' / ' + state.all.length;
  }

  /* ===== 卡面 ===== */
  function railButtons(card) {
    var markOn = card.is_unknown === 1;
    var favOn = card.is_favorite === 1;
    return '<div class="dc-acts">' +
      '<button type="button" data-action="play" data-tooltip="读量词"><i class="fa-solid fa-volume-high"></i></button>' +
      '<button type="button" class="act-mark' + (markOn ? ' is-active' : '') + '" data-action="mark" data-tooltip="' +
        (markOn ? '取消标记' : '标记为不认识') + '"><i class="' + (markOn ? 'fa-solid' : 'fa-regular') + ' fa-star"></i></button>' +
      '<button type="button" class="act-fav' + (favOn ? ' is-active' : '') + '" data-action="favorite" data-tooltip="' +
        (favOn ? '取消收藏' : '收藏') + '"><i class="' + (favOn ? 'fa-solid' : 'fa-regular') + ' fa-bookmark"></i></button>' +
      '</div>';
  }

  function introCard() {
    var c = state.intro;
    if (!c) return '';
    var d = c.data || {};
    var leg = CATS.map(function (k) {
      return '<span class="mw-lg ' + catClass(k) + '"><i></i>' + esc(k) + ' · ' + esc(CAT_EN[k] || '') + '</span>';
    }).join('');
    return '<div class="mw-root mw-intro" data-card-id="' + c.id + '">' +
      '<div class="mw-intro-body">' +
        '<div class="mw-i-title">' + esc(d.nameZh || '量词') + '</div>' +
        '<div class="mw-i-en">' + esc(d.nameEn || 'Measure Words') + '</div>' +
        '<div class="mw-i-formula"><b>数词</b><span>+</span><b>量词</b><span>+</span><b>名词</b>' +
          '<span class="mw-i-fen">number + measure word + noun</span></div>' +
        '<div class="mw-i-sec">七类量词 · The 7 kinds in this deck</div>' +
        '<div class="mw-legend">' + leg + '</div>' +
      '</div>' +
    '</div>';
  }

  function renderCard(card) {
    var d = card.data || {};
    if (d.type === 'intro') return introCard();

    var cols = Array.isArray(d.collocations) ? d.collocations : [];
    var lv = LV_TEXT[d.level] || d.level || '';
    var chips = cols.length
      ? '<div class="mw-chips">' + cols.map(function (s) {
          return '<span class="mw-chip ' + catClass(d.category) + '" data-word="' + esc(s) +
            '" data-tooltip="读 ' + esc(s) + '">' + esc(s) + '</span>';
        }).join('') + '</div>'
      : '';
    return '<div class="mw-root ' + catClass(d.category) + '" data-card-id="' + card.id + '">' +
      railButtons(card) +
      '<div class="mw-top">' +
        (lv ? '<span class="mw-lv">' + esc(lv) + '</span>' : '') +
        '<span class="mw-cat">' + esc(d.category) + '</span>' +
      '</div>' +
      '<div class="mw-word">' + esc(d.mw) +
        (d.pinyin ? '<span class="mw-py">' + esc(d.pinyin) + '</span>' : '') + '</div>' +
      (d.usage ? '<div class="mw-usage">' + esc(d.usage) + '</div>' : '') +
      chips +
      (d.example ? '<div class="mw-ex" data-word="' + esc(d.example) + '" data-tooltip="读整句">' + esc(d.example) + '</div>' : '') +
      (d.exampleEn ? '<div class="mw-exen">' + esc(d.exampleEn) + '</div>' : '') +
    '</div>';
  }

  /* ===== 分类速查表 ===== */
  function chartCell(card) {
    var d = card.data || {};
    return '<div class="c-cell ' + catClass(d.category) + '" data-card-id="' + card.id + '" data-act="jump"' +
      ' data-tooltip="' + esc(d.mw) + ' · ' + esc(d.category) + ' · 点一下看卡片">' +
      (card.is_unknown === 1 ? '<span class="c-star"><i class="fa-solid fa-star"></i></span>' : '') +
      (card.is_favorite === 1 ? '<span class="c-fav"><i class="fa-solid fa-bookmark"></i></span>' : '') +
      '<span class="c-mw">' + esc(d.mw) + '</span>' +
      '<span class="c-py">' + esc(d.pinyin) + '</span>' +
      '<span class="c-lv">' + esc(LV_TEXT[d.level] || '') + '</span>' +
      '</div>';
  }

  function renderChart() {
    var box = $id('study-list');
    var cards = visibleCards();
    if (!cards.length) {
      box.innerHTML = '<div class="empty-state">' +
        (state.coreOnly ? '这组里没有 HSK1-4 的量词。' : '还没有卡片。') + '</div>';
      return;
    }
    var html = '';
    CATS.forEach(function (cat) {
      var group = cards.filter(function (c) { return (c.data || {}).category === cat; });
      if (!group.length) return;
      html += '<div class="mw-band ' + catClass(cat) + '">' +
        '<div class="mw-band-head"><span class="mw-band-zh">' + esc(cat) + '</span>' +
        '<span class="mw-band-en">' + esc(CAT_EN[cat] || '') + '</span>' +
        '<span class="mw-band-n">' + group.length + '</span></div>' +
        '<div class="mw-grid">' + group.map(chartCell).join('') + '</div>' +
      '</div>';
    });
    box.innerHTML = html;
  }

  /* ===== 渲染 ===== */
  function renderList() {
    var box = $id('study-list');
    if (!box) return;
    var content = $('.study-content');
    var isChart = (state.view === 'chart' && !state.singleCardMode);
    if (content) {
      content.classList.toggle('wide', state.singleCardMode);
      content.classList.toggle('chart-wide', isChart);
    }
    if (state.singleCardMode) { renderSingleCardStage(); return; }
    if (isChart) { renderChart(); return; }

    var cards = visibleCards();
    if (!cards.length) {
      box.innerHTML = '<div class="empty-state">' +
        (state.coreOnly ? '这组里没有 HSK1-4 的量词。' : '还没有卡片。') + '</div>';
      return;
    }
    var head = (state.intro && !state.coreOnly) ? introCard() : '';
    box.innerHTML = head + cards.map(function (c, i) {
      return '<div class="enter" style="animation-delay:' + Math.min(i * 14, 260) + 'ms">' +
        renderCard(c) + '</div>';
    }).join('');
  }
  function patchCard(card) {
    if (state.view === 'chart') { patchCell(card); return; }
    var el = document.querySelector('#study-list [data-card-id="' + card.id + '"]');
    if (!el) { renderList(); return; }
    var host = el.parentElement;
    if (host && host.classList.contains('enter')) host.innerHTML = renderCard(card);
    else el.outerHTML = renderCard(card);
  }
  function patchCell(card) {
    var el = document.querySelector('#study-list .c-cell[data-card-id="' + card.id + '"]');
    if (el) el.outerHTML = chartCell(card);
  }

  /* ===== 单卡模式 ===== */
  function toggleSingleCardMode() {
    if (state.view !== 'card') return;
    state.singleCardMode = !state.singleCardMode;
    state.singleCardIndex = 0;
    var btn = $id('card-view-btn');
    if (btn) btn.classList.toggle('active', state.singleCardMode);
    renderList();
  }
  function exitSingleCardMode() {
    if (!state.singleCardMode) return;
    state.singleCardMode = false;
    var btn = $id('card-view-btn');
    if (btn) btn.classList.remove('active');
    renderList();
  }
  function renderSingleCardStage() {
    var box = $id('study-list');
    if (!box) return;
    var cards = visibleCards();
    if (!cards.length) { box.innerHTML = '<div class="empty-state">还没有卡片。</div>'; return; }
    var prevSvg = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 15 12 9 18 15"/></svg>';
    var nextSvg = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
    box.innerHTML =
      '<div class="single-card-stage">' +
        '<div class="sc-main"><div class="sc-card-wrap" id="sc-card-wrap"></div></div>' +
        '<div class="sc-nav-col">' +
          '<button class="sc-nav sc-prev" data-sc="prev" data-tooltip="上一张" aria-label="上一张">' + prevSvg + '</button>' +
          '<div class="sc-progress"><span id="sc-idx">1</span> / ' + cards.length + '</div>' +
          '<button class="sc-nav sc-next" data-sc="next" data-tooltip="下一张" aria-label="下一张">' + nextSvg + '</button>' +
        '</div>' +
      '</div>';
    renderSingleCardContent(state.singleCardIndex, false);
  }
  function renderSingleCardContent(idx, animate) {
    var cards = visibleCards();
    if (!cards.length) return;
    if (idx < 0) idx = cards.length - 1;
    if (idx >= cards.length) idx = 0;
    state.singleCardIndex = idx;
    var wrap = $id('sc-card-wrap');
    if (!wrap) return;
    wrap.innerHTML = renderCard(cards[idx]);
    var idxEl = $id('sc-idx');
    if (idxEl) idxEl.textContent = idx + 1;
    if (animate) {
      var target = wrap.firstElementChild || wrap;
      target.classList.remove('sc-anim');
      void target.offsetWidth;
      target.classList.add('sc-anim');
    }
  }
  function singleCardNav(delta) {
    renderSingleCardContent(state.singleCardIndex + delta, true);
  }

  /* ===== 交互 ===== */
  function playMw(card) {
    var d = card.data || {};
    cardAPI.track('audio_play', card.id);
    if (!d.mw) { showToast('这张卡没有可朗读的内容', true); return; }
    warnIfNoVoice();
    voiceMgr.speak(d.mw, VOICE_LANG);
  }
  function playWord(card, word) {
    if (!word) return;
    cardAPI.track('word_play', card.id);
    warnIfNoVoice();
    voiceMgr.speak(word, VOICE_LANG);
  }
  function handleMark(card) {
    var want = card.is_unknown === 1 ? 0 : 1;
    cardAPI.mark(card.id, want).then(function (d) {
      card.is_unknown = (d && typeof d.is_unknown !== 'undefined') ? d.is_unknown : want;
      cardAPI.track('word_mark', card.id);
      if (state.view === 'chart') patchCell(card);
      else if (state.singleCardMode) renderSingleCardContent(state.singleCardIndex, false);
      else patchCard(card);
      updateStatsText();
    });
  }
  function handleFavorite(card) {
    var want = card.is_favorite === 1 ? 0 : 1;
    cardAPI.favorite(card.id, want).then(function (d) {
      card.is_favorite = (d && typeof d.is_favorite !== 'undefined') ? d.is_favorite : want;
      cardAPI.track('favorite_toggle', card.id);
      if (state.view === 'chart') patchCell(card);
      else if (state.singleCardMode) renderSingleCardContent(state.singleCardIndex, false);
      else patchCard(card);
    });
  }

  /* 从速查表跳到卡片 */
  function jumpToCard(id) {
    var card = findCard(id);
    if (!card) return;
    playMw(card);
    if (state.view === 'card' && !state.singleCardMode) { scrollToCard(card); return; }
    setView('card');
    scrollToCard(card);
  }
  function scrollToCard(card) {
    requestAnimationFrame(function () {
      var el = document.querySelector('#study-list [data-card-id="' + card.id + '"]');
      if (!el) return;
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      el.classList.remove('mw-flash');
      void el.offsetWidth;
      el.classList.add('mw-flash');
      setTimeout(function () { el.classList.remove('mw-flash'); }, 1400);
    });
  }

  /* ===== 视图切换 ===== */
  function renderViewSeg() {
    var box = $id('view-seg');
    if (!box) return;
    box.innerHTML = VIEWS.map(function (v) {
      return '<button type="button" data-view="' + v.id + '"' + (state.view === v.id ? ' class="on"' : '') + '>' +
        esc(v.label) + '</button>';
    }).join('');
  }
  function setView(id) {
    if (!VIEWS.some(function (v) { return v.id === id; })) return;
    if (state.view === id && !state.singleCardMode) return;
    state.view = id;
    state.singleCardMode = false;
    state.singleCardIndex = 0;
    try { localStorage.setItem(LS + 'view', id); } catch (e) {}
    var cv = $id('card-view-btn');
    if (cv) {
      cv.classList.remove('active');
      cv.style.display = (id === 'chart') ? 'none' : '';
    }
    renderViewSeg();
    renderList();
    updateStatsText();
    var s = $id('study-scroll');
    if (s) s.scrollTop = 0;
  }
  function setCoreOnly(on) {
    state.coreOnly = !!on;
    try { localStorage.setItem(LS + 'core', state.coreOnly ? '1' : '0'); } catch (e) {}
    var btn = $id('core-only-btn');
    if (btn) btn.classList.toggle('active', state.coreOnly);
    renderList();
    showToast(state.coreOnly ? '只看 HSK1-4 的 ' + visibleCards().length + ' 个量词' : '显示全部 ' + state.all.length + ' 个量词');
  }

  /* ===== 事件委托 ===== */
  function bindEvents() {
    document.addEventListener('click', function (e) {
      var target = e.target;
      if (!target || typeof target.closest !== 'function') return;

      /* 搭配 chip / 例句 = 读那个词/句 */
      var wordEl = target.closest('[data-word]');
      if (wordEl) {
        e.stopPropagation();
        var wCardEl = wordEl.closest('[data-card-id]');
        var wCard = wCardEl ? findCard(wCardEl.dataset.cardId) : null;
        if (wCard) playWord(wCard, wordEl.dataset.word);
        return;
      }
      /* 速查表格子 = 读量词 + 跳卡 */
      var cell = target.closest('.c-cell[data-act="jump"]');
      if (cell) {
        e.stopPropagation();
        jumpToCard(cell.dataset.cardId);
        return;
      }
      /* 卡片动作 */
      var actionBtn = target.closest('[data-action]');
      if (actionBtn) {
        e.stopPropagation();
        var cardEl = actionBtn.closest('[data-card-id]');
        var card = cardEl ? findCard(cardEl.dataset.cardId) : null;
        if (card) {
          var action = actionBtn.dataset.action;
          if (action === 'play') playMw(card);
          else if (action === 'mark') handleMark(card);
          else if (action === 'favorite') handleFavorite(card);
        }
        return;
      }
      if (target.closest('[data-sc="prev"]')) { singleCardNav(-1); return; }
      if (target.closest('[data-sc="next"]')) { singleCardNav(1); return; }

      /* 分类速查 / 卡片 */
      var viewBtn = target.closest('#view-seg button');
      if (viewBtn) { setView(viewBtn.dataset.view); return; }

      /* 只看 HSK1-4 */
      if (target.closest('#core-only-btn')) { setCoreOnly(!state.coreOnly); return; }

      /* 皮肤下拉 */
      if (target.closest('#style-btn')) {
        var dd = $id('style-dropdown');
        renderSkinList();
        dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
        return;
      }
      var styleOpt = target.closest('[data-style]');
      if (styleOpt) {
        state.skin = styleOpt.dataset.style;
        applySkin();
        $id('style-dropdown').style.display = 'none';
        return;
      }

      /* 音色下拉 */
      if (target.closest('.voice-select-btn')) {
        var vdd = $('.voice-dropdown');
        renderVoiceDropdown();
        vdd.style.display = vdd.style.display === 'none' ? 'block' : 'none';
        return;
      }
      var vOpt = target.closest('.voice-option:not(.muted)');
      if (vOpt) {
        var uri = vOpt.dataset.voiceUri;
        var picked = null;
        for (var i = 0; i < voiceMgr.voices.length; i++) {
          if (voiceMgr.voices[i].voiceURI === uri) { picked = voiceMgr.voices[i]; break; }
        }
        voiceMgr.saveVoice(VOICE_LANG, picked);
        renderVoiceDropdown();
        $('.voice-dropdown').style.display = 'none';
        voiceMgr.speak(voiceMgr.sampleText(), VOICE_LANG);
        return;
      }

      /* 字体抽屉 */
      if (target.closest('#font-settings-btn')) {
        var drawer = $id('font-drawer');
        var fbtn = target.closest('#font-settings-btn');
        var r = fbtn.getBoundingClientRect();
        drawer.style.top = (r.bottom + 8) + 'px';
        drawer.style.left = (r.left + r.width / 2) + 'px';
        drawer.style.transform = 'translateX(-50%)';
        drawer.style.display = drawer.style.display === 'none' ? 'block' : 'none';
        return;
      }
      if (target.closest('#font-size-minus')) {
        state.fontSize = Math.max(0.6, Math.round((state.fontSize - 0.1) * 10) / 10);
        applyCardFont();
        return;
      }
      if (target.closest('#font-size-plus')) {
        state.fontSize = Math.min(1.5, Math.round((state.fontSize + 0.1) * 10) / 10);
        applyCardFont();
        return;
      }
      if (target.closest('#reset-fonts')) { state.fontSize = 1; applyCardFont(); return; }

      /* 刷新 */
      if (target.closest('#refresh-stats')) {
        if (!state._refreshLock) {
          state._refreshLock = true;
          loadAll().then(function () { renderList(); updateStatsText(); });
          showToast('已刷新');
          setTimeout(function () { state._refreshLock = false; }, 1000);
        }
        return;
      }

      if (target.closest('#card-view-btn')) { toggleSingleCardMode(); return; }
      if (target.closest('#scroll-top-btn')) { $id('study-scroll').scrollTo({ top: 0, behavior: 'smooth' }); return; }
      if (target.closest('#scroll-bottom-btn')) {
        var s = $id('study-scroll');
        s.scrollTo({ top: s.scrollHeight, behavior: 'smooth' });
        return;
      }

      /* 点空白处收起浮层 */
      if (!target.closest('#style-dropdown') && !target.closest('#style-btn')) {
        var sdd = $id('style-dropdown');
        if (sdd) sdd.style.display = 'none';
      }
      if (!target.closest('.voice-dropdown') && !target.closest('.voice-select-btn')) {
        var vd = $('.voice-dropdown');
        if (vd) vd.style.display = 'none';
      }
      if (!target.closest('#font-drawer') && !target.closest('#font-settings-btn')) {
        var fd = $id('font-drawer');
        if (fd) fd.style.display = 'none';
      }
    });

    document.addEventListener('keydown', function (e) {
      if (!state.singleCardMode) return;
      if (e.key === 'ArrowLeft') { e.preventDefault(); singleCardNav(-1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); singleCardNav(1); }
      else if (e.key === ' ' || e.key === 'Spacebar') { e.preventDefault(); singleCardNav(1); }
      else if (e.key === 'Escape') { e.preventDefault(); exitSingleCardMode(); }
    });
  }

  /* ===== 初始化 ===== */
  function init() {
    applySkin();
    applyCardFont();
    initTooltip();
    voiceMgr.init();
    bindEvents();

    document.title = TITLE;
    var title = $id('study-deck-title');
    if (title) title.textContent = TITLE;

    var cv = $id('card-view-btn');
    if (cv) cv.style.display = (state.view === 'chart') ? 'none' : '';
    var co = $id('core-only-btn');
    if (co) co.classList.toggle('active', state.coreOnly);

    renderViewSeg();
    renderList();

    loadAll().then(function () {
      renderViewSeg();
      renderList();
      updateStatsText();
    }).catch(function () {
      var box = $id('study-list');
      if (box) box.innerHTML = '<div class="empty-state">卡组数据加载失败。</div>';
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
